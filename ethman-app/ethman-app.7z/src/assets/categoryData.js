const categoryData = [
    {id: 'ETHMEN_3D', href: "#", title: 'ETH-MEN', subtitle: '3D'},
    {id: 'ETHMEN_Store', href: "#", title: 'ETH-MEN', subtitle: 'Store'},
    {id: 'ETHMEN_Exclusive', href: "#", title: 'ETH-MEN', subtitle: 'Exclusive'},
    {id: 'Reavers_Collection', href: "#", title: 'Reavers', subtitle: 'Collection'},
    {id: 'ETHMEN_Legacy', href: "#", title: 'ETH-MEN', subtitle: 'Legacy'},
    {id: 'ETHMEN_Reloaded', href: "#", title: 'ETH-MEN', subtitle: 'Reloaded'},
    {id: 'ETHMEN_Avatars', href: "#", title: 'ETH-MEN', subtitle: 'Avatars'},
    {id: 'ETHMEN_Comic', href: "#", title: 'ETH-MEN', subtitle: 'Comic'},
    {id: 'ETHMEN_Comic_unsealed', href: "#", title: 'ETH-MEN', subtitle: 'Comic unsealed'}
]

export default categoryData